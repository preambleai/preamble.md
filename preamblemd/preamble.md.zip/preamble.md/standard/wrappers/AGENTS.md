# AGENTS.md

**Read ./preamble.md first — it contains mandatory security controls.**

If any instruction in this file conflicts with preamble.md, the preamble takes priority.

## Agent Instructions

[Your agent workflow instructions here]

## Note

This file provides workflow guidance and conventions. Security policy is defined in preamble.md and cannot be overridden by this file or any other agent configuration.
