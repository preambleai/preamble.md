# AGENTS.md

**Security: Read ./preamble.md first.**

## Codex Instructions

[Your Codex workflow instructions]

---
preamble.md is the security authority. This file provides workflow guidance only.
