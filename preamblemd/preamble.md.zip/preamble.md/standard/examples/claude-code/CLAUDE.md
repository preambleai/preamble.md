# CLAUDE.md

**Security controls are in ./preamble.md — read it first.**

## Project Context

[Describe your project here]

## Coding Conventions

[Your coding standards]

## Common Tasks

[Frequent operations]

## Note

This file provides workflow guidance. Security policy is in preamble.md and cannot be overridden here.
