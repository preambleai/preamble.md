# AGENTS.md

**Security: Read ./preamble.md first.**

## Windsurf Cascade Instructions

[Your Cascade workflow instructions]

---
preamble.md is the security authority. This file provides workflow guidance only.
